﻿using GUILab05.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUILab05.Services
{
    public interface ISnackEditorService
    {
        void Edit(Snack snack);
    }
}
