﻿using GUILab05.Models;
using GUILab05.Services;
using Microsoft.Toolkit.Mvvm.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUILab05.Logic
{
    public class SnackLogic : ISnackLogic
    {
        IList<Snack> snacks;
        IList<Snack> cart;
        IMessenger messenger;
        ISnackEditorService editorService;
        public SnackLogic(IMessenger messenger, ISnackEditorService editorService)
        {
            this.messenger = messenger;
            this.editorService = editorService;
        }

        public int AllCost
        {
            get
            {
                return snacks.Count == 0 ? 0 : cart.Sum(x => x.Price);
            }
        }

        public void SetupCollection(IList<Snack> snacks, IList<Snack> cart)
        {
            this.snacks = snacks;
            this.cart = cart;
        }

        public void AddToCart(Snack s)
        {
            if (s.Quantity!=0)
            {
                cart.Add(s.GetCopy());
                if (s.Quantity > 0)
                {
                    s.Quantity--;
                }
                messenger.Send("Snack Added", "SnackInfo");
            }
        }

        public void RemoveFromCart(Snack s)
        {
            snacks.Remove(s);
            messenger.Send("Snack Removed", "SnackInfo");
        }

        public void EditSnack(Snack s)
        {
            editorService.Edit(s);
        }

        public void AddNewSnack()
        {
            var s = new Snack();
            editorService.Edit(s);
            snacks.Add(s);

        }
    }
}
