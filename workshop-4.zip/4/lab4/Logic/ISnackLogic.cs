﻿using GUILab05.Models;
using System.Collections.Generic;

namespace GUILab05.Logic
{
    public interface ISnackLogic
    {
        int AllCost { get; }

        void AddNewSnack();
        void AddToCart(Snack s);
        void EditSnack(Snack s);
        void RemoveFromCart(Snack s);
        void SetupCollection(IList<Snack> snacks, IList<Snack> cart);
    }
}