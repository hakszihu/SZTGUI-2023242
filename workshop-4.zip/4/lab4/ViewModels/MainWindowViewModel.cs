﻿using GUILab05.Logic;
using GUILab05.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.DependencyInjection;
using Microsoft.Toolkit.Mvvm.Input;
using Microsoft.Toolkit.Mvvm.Messaging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GUILab05.ViewModels
{
    public class MainWindowViewModel : ObservableRecipient
    {
        ISnackLogic logic;
        public ObservableCollection<Snack> Snacks { get; set; }
        public ObservableCollection<Snack> Cart { get; set; }

        private Snack selectedFromSnacks;

        public Snack SelectedFromSnacks
        {
            get { return selectedFromSnacks; }
            set 
            {
                SetProperty(ref selectedFromSnacks , value);
                (AddToCartCommand as RelayCommand).NotifyCanExecuteChanged();
                (EditSnackCommand as RelayCommand).NotifyCanExecuteChanged();
                (RemoveFromSnacksCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public int AllPrice
        {
            get
            {
                return logic.AllCost;
            }
        }

        public ICommand AddToCartCommand { get; set; }

        public ICommand RemoveFromSnacksCommand { get; set; }

        public ICommand EditSnackCommand { get; set; }

        public ICommand AddNewSnackCommand { get; set; }



        public static bool IsInDesingMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }

        public MainWindowViewModel()
            :this(IsInDesingMode ? null : Ioc.Default.GetService<ISnackLogic>())
        {
            
        }

        public MainWindowViewModel(ISnackLogic logic)
        {
            this.logic = logic;
            Snacks = new ObservableCollection<Snack>();
            Cart = new ObservableCollection<Snack>();

            Snacks.Add(new Snack()
            {
                Name="Twix",
                Price=300,
                Quantity=20
            });
            Snacks.Add(new Snack()
            {
                Name="Mars",
                Price=300,
                Quantity=16
            });
            Snacks.Add(new Snack()
            {
                Name="Balaton Szelet",
                Price=250,
                Quantity=4
            });
            Snacks.Add(new Snack()
            {
                Name="Sport szelet",
                Price=200,
                Quantity=9
            });
            Snacks.Add(new Snack()
            {
                Name="Waffelini",
                Price=260,
                Quantity=15
            });
            Snacks.Add(new Snack()
            {
                Name="KitKat",
                Price=350,
                Quantity=0
            });
            Snacks.Add(new Snack()
            {
                Name="3Bit",
                Price=340,
                Quantity=18
            });

            logic.SetupCollection(Snacks, Cart);
            
            AddNewSnackCommand = new RelayCommand
                (
                    () => logic.AddNewSnack()
                );
            RemoveFromSnacksCommand = new RelayCommand
                (
                    ()=>logic.RemoveFromCart(SelectedFromSnacks),
                    ()=> SelectedFromSnacks != null
                );
            EditSnackCommand = new RelayCommand
                (
                    ()=> logic.EditSnack(SelectedFromSnacks),
                    ()=> SelectedFromSnacks != null
                );
            AddToCartCommand = new RelayCommand
                (
                    () => logic.AddToCart(SelectedFromSnacks),
                    () => SelectedFromSnacks != null && SelectedFromSnacks.Quantity>0
                );


            Messenger.Register<MainWindowViewModel, string, string>(this, "SnackInfo", (recipient, msg)=>{

                OnPropertyChanged("AllPrice");
            });
        }
    }
}
