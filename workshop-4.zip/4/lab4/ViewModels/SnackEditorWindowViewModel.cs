﻿using GUILab05.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUILab05.ViewModels
{
    public class SnackEditorWindowViewModel
    {
        public Snack Actual { get; set; }

        public void Setup(Snack snack)
        {
            this.Actual = snack;
        }

        public SnackEditorWindowViewModel()
        {

        }
    }
}
