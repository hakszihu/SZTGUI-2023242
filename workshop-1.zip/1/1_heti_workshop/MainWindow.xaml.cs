﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _1_heti_workshop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<Jegyzet> _items;
        string tmp_button_name;

        public MainWindow()
        {
            InitializeComponent();

            if (File.Exists("jegyzetek.json"))
            {
                _items = JsonConvert.DeserializeObject<List<Jegyzet>>(File.ReadAllText("jegyzetek.json"));
            }
            else
            {
                _items= new List<Jegyzet>();
            }
            foreach (var item in _items)
            {
                var _Button = new Button { Content = item.Nev};
                _Button.Click += Button_Click2;
                _Button.Width = 120;
                _Button.HorizontalAlignment = HorizontalAlignment.Center;
                _Button.VerticalAlignment = VerticalAlignment.Center;
                listbox.Items.Add(_Button);
            }

            }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            
            if ((tb_content.Text != "" || tb_content.Text != null) && !_items.Select(x => x.Nev).Equals(tb_newfeljegyzes.Text))//?
            {
                _items.Add(new Jegyzet { Nev = tb_newfeljegyzes.Text, Tartalom = tb_content.Text });
                var _Button = new Button { Content = tb_newfeljegyzes.Text };
                _Button.Click += Button_Click2;
                _Button.Width = 120;
                _Button.HorizontalAlignment = HorizontalAlignment.Center;
                _Button.VerticalAlignment = VerticalAlignment.Center;
                listbox.Items.Add(_Button);
            }
        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            tmp_button_name = ((Button)e.Source).Content.ToString();
            tb_content.Text = _items.Select(x => x).Where(x => x.Nev.Equals(tmp_button_name)).First().Tartalom;

        }

        private void tb_newfeljegyzes_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            //ide kell a modositas
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string jsonData = JsonConvert.SerializeObject(_items);
            File.WriteAllText("jegyzetek.json", jsonData);
        }
    }
}
