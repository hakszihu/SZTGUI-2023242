﻿namespace worksop_03
{
    internal class EtelBase
    {
    }
}